---
name: extract-video-training-samples
agent_created: true
description: Extract positive and negative training samples from a gameplay video using an existing ONNX classifier. Crop the region of interest for every Nth frame, score each crop with the classifier, and save the top-scored frames as positives and the bottom-scored frames as negatives.
---

# Extract Video Training Samples

## Overview

When the user wants to build or expand a binary classifier for a specific UI element (e.g., a game prompt like “精准收招”), a common first step is to extract positive and negative samples from a recorded video. This skill automates that step: sample frames from a video, crop the region of interest, run an existing ONNX classifier on each crop, and split the highest/lowest scoring frames into two folders.

Use this skill when:

- The user provides a video file and asks for positive/negative training samples.
- There is already an ONNX classifier for the target UI element.
- The project already defines a relative search region for the UI element.

## Workflow

1. **Inspect the video**
   - Read the video with `cv2.VideoCapture` to get resolution, FPS, and frame count.
   - Decide a sampling interval (e.g., every 5 frames) to avoid redundant frames while keeping enough variety.

2. **Determine the crop region**
   - Use the same relative `SEARCH_REGION` as the live monitor script (e.g., `(0.7104, 0.7222, 0.7794, 0.8148)`).
   - Convert to absolute pixels based on the video resolution: `left = W * x1`, `top = H * y1`, `right = W * x2`, `bottom = H * y2`.

3. **Run the ONNX classifier on each crop**
   - Load the model with `onnxruntime.InferenceSession(..., providers=["CPUExecutionProvider"])`.
   - Resize the crop to the classifier input size (usually 224×224).
   - Normalize with ImageNet mean/std: `(x - [0.485, 0.456, 0.406]) / [0.229, 0.224, 0.225]`.
   - Convert HWC → CHW and add a batch dimension.
   - Run inference and take the softmax probability of the positive class.

4. **Select and save samples**
   - Sort all sampled frames by positive probability.
   - Save the top N frames as positives and the bottom N frames as negatives.
   - Include the probability and frame index in the filename for easy review.

5. **Review the output**
   - High-confidence positives (e.g., probability ≥ 0.8) are usually reliable.
   - Frames near the decision boundary (probability ~0.5–0.6) may be false positives and should be spot-checked.

## Reference Script

- `scripts/extract_video_samples.py` — ready-to-use Python script that implements the workflow above.

## Typical Command

```cmd
G:\Users\qq295\.workbuddy\binaries\python\envs\default\Scripts\python.exe extract_video_samples.py "G:\Users\qq295\Videos\Captures\video.mp4"
```

Outputs:

- `positive_samples/` — top-scored frames (e.g., 200)
- `negative_samples/` — bottom-scored frames (e.g., 200)
